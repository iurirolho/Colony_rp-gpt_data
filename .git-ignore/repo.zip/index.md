---
title: Colony Survival Sim
---
# Colony Survival Sim — Prompt Manifest
- [Manifest](/manifest/v1.json)
- [Schemas](/cfg/schemas.v1.json)
- [Governor](/cfg/governor.v1.json)
- [Encounters](/cfg/encounter.v1.json)
- [Tuning](/cfg/tuning.v1.json)
- [Strict Mode](/cfg/mode.strict.v1.json)
- [Output Contract](/cfg/output_contract.v1.txt)
- [Filters](/cfg/filters.v1.json)
- [Sample Pack](/cfg/packs/sample_state.b85)
