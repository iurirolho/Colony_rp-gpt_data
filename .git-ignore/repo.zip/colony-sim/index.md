---
title: Colony Survival Sim
---
# Colony Survival Sim — Prompt Manifest
This site serves static JSON config for a text-based survival simulation.
See [`manifest/v1.json`](manifest/v1.json).
